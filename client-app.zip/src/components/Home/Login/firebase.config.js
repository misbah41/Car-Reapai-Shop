const firebaseConfig = {
  apiKey: "AIzaSyBPnf96I9YWuHRSq7iCEW5--7I0S5bZzuE",
  authDomain: "car-repairing-6310c.firebaseapp.com",
  projectId: "car-repairing-6310c",
  storageBucket: "car-repairing-6310c.appspot.com",
  messagingSenderId: "355217888576",
  appId: "1:355217888576:web:2d45741a131f5bcd6c96a5"
};
export default firebaseConfig;