import React from "react";
import ContactForm from "../ContactForm/ContactForm";
import './Contact.css'



const Contact = () => {



  return (
    <>
    <ContactForm/>
    </>
  );
};

export default Contact;
