import React from 'react';
import Sidebar from '../SideBar/Sidebar';

const ManageServices = () => {
  return (
    <div className="d-flex">
      <div>
        <Sidebar />
      </div>
      <div>
        <h3>This is ManageServices page</h3>
      </div>
    </div>
  );
};

export default ManageServices;