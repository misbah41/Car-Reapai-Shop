import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import "./SideBar.css";
const Sidebar = () => {
  const [isAdmin, setIsAdmin] = useState(false);
  const userEmail = localStorage.getItem("userEmail");

  useEffect(() => {
    fetch("http://localhost:3500/isAdmin", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email: userEmail }),
    })
      .then((response) => response.json())
      .then((data) => setIsAdmin(data));
  }, []);

  return (
    <aside className="sidebar">
      <ul>
        {isAdmin ? (
          <div>
            <li className="nav-item">
              <Link className="nav-link sidebar-link" to="/addservices">
                Add Service
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link sidebar-link" to="/createadmin">
                Create Admin
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link sidebar-link" to="/usersorder">
                Users Order
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link sidebar-link" to="/manageservices">
                Manage Services
              </Link>
            </li>
          </div>
        ) : (
          <div>
            <li className="nav-item">
              <Link className="nav-link sidebar-link" to="/servicecheckout">
                Order
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link sidebar-link" to="/orderlist">
                Order List
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link sidebar-link" to="/review">
                Review
              </Link>
            </li>
          </div>
        )}
      </ul>
    </aside>
  );
};

export default Sidebar;
